■ファイル一覧
stockGetter.exe…実行ファイル。起動に数秒要する
stocklist.txt…株の銘柄コードを1行に1つ記載。exeファイルと同階層にこれがないと動きません
stocks.csv…stockGetter.exe実行後に自動生成される。銘柄コードや株価が記載される

■履歴
2025/01/11 初期版作成